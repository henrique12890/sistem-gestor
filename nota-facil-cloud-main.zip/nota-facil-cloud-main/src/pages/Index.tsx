
import Header from "@/components/layout/Header";
import Hero from "@/components/sections/Hero";
import Features from "@/components/sections/Features";
import Pricing from "@/components/sections/Pricing";

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="bg-gradient-to-b from-primary to-primary-light text-white">
        <Hero />
        <Features />
        <Pricing />
      </main>
    </div>
  );
};

export default Index;
