
import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonPremiumProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary";
}

const ButtonPremium = forwardRef<HTMLButtonElement, ButtonPremiumProps>(
  ({ className, variant = "primary", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "relative px-6 py-3 font-medium text-sm transition-all duration-300",
          "before:absolute before:inset-0 before:rounded-full before:transition-all before:duration-300",
          variant === "primary"
            ? "text-white before:bg-gradient-to-r before:from-primary-accent before:to-primary-accent/90 hover:before:scale-105"
            : "text-primary before:bg-secondary hover:before:scale-105",
          "hover:before:opacity-90",
          className
        )}
        {...props}
      >
        <span className="relative">{props.children}</span>
      </button>
    );
  }
);

ButtonPremium.displayName = "ButtonPremium";

export default ButtonPremium;
