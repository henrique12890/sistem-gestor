
import { useState, useEffect } from "react";
import ButtonPremium from "../ui/button-premium";
import { Menu, X } from "lucide-react";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/80 backdrop-blur-lg shadow-sm" : ""
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-24"> {/* Aumentei a altura do container */}
          <div className="flex items-center gap-2">
            <img 
              src="/lovable-uploads/a0c2a262-e5f8-4a7e-99ce-66fa4b8931a9.png" 
              alt="System Gestor Logo" 
              className="h-24 w-auto" // Logo ainda maior
            />
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            <a href="#features" className="text-white hover:text-primary-accent transition-colors">
              Recursos
            </a>
            <a href="#testimonials" className="text-white hover:text-primary-accent transition-colors">
              Depoimentos
            </a>
            <a href="#pricing" className="text-white hover:text-primary-accent transition-colors">
              Planos
            </a>
            <a href="https://sistemgestor.appnfe.com/" target="_blank" rel="noopener noreferrer">
              <ButtonPremium>Experimente Grátis</ButtonPremium>
            </a>
          </nav>

          <button
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6 text-white" />
            ) : (
              <Menu className="h-6 w-6 text-white" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="px-2 pt-2 pb-3 space-y-1">
            <a
              href="#features"
              className="block px-3 py-2 text-white hover:text-primary-accent transition-colors"
            >
              Recursos
            </a>
            <a
              href="#testimonials"
              className="block px-3 py-2 text-white hover:text-primary-accent transition-colors"
            >
              Depoimentos
            </a>
            <a
              href="#pricing"
              className="block px-3 py-2 text-white hover:text-primary-accent transition-colors"
            >
              Planos
            </a>
            <div className="px-3 py-2">
              <a href="https://sistemgestor.appnfe.com/" target="_blank" rel="noopener noreferrer" className="w-full block">
                <ButtonPremium className="w-full">Experimente Grátis</ButtonPremium>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
