
import { Check } from "lucide-react";
import ButtonPremium from "../ui/button-premium";

const Features = () => {
  const benefits = [
    "Emita os três principais tipos de notas (NF-e, NFS-e, NFC-e)",
    "Use seu celular ou seu computador (sem limitações)",
    "Ganhe velocidade emitindo notas fiscais em segundos",
    "Todas as notas salvas na nuvem",
    "Sistema simples e fácil de usar",
    "Seguro e robusto (não deixa você na mão)",
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Conheça tudo que Sistem Gestor oferece para facilitar seu negócio
          </h2>
          <p className="text-xl text-gray-600">
            O Software mais prático do mercado!
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="flex items-start space-x-4 p-4 rounded-lg bg-white shadow-sm"
              >
                <div className="flex-shrink-0">
                  <div className="p-1 rounded-full bg-primary/10">
                    <Check className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <p className="text-gray-700">{benefit}</p>
              </div>
            ))}
          </div>

          <div className="text-center md:text-left">
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <h3 className="text-2xl font-bold mb-6">
                Comece a usar agora mesmo!
              </h3>
              <p className="text-gray-600 mb-8">
                Experimente gratuitamente e descubra como podemos ajudar seu negócio.
              </p>
              <ButtonPremium className="w-full">
                EXPERIMENTE GRÁTIS
              </ButtonPremium>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
