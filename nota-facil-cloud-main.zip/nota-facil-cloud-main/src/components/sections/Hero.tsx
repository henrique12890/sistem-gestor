
import ButtonPremium from "../ui/button-premium";
import { ArrowRight, FileText, Cloud, Smartphone } from "lucide-react";

const Hero = () => {
  return (
    <section className="pt-32 pb-20 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-white text-sm font-medium mb-6 animate-fade-in">
            Sistema de Notas Fiscais
          </span>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
            O sistema mais eficiente para emitir suas notas fiscais em segundos!
          </h1>
          <p className="text-xl text-white/80 mb-8 animate-fade-in">
            Emissão dos 3 principais tipos de notas fiscais eletrônicas: NF-e / NFC-e / NFS-e
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mb-12 animate-fade-in">
            <a href="https://sistemgestor.appnfe.com/" target="_blank" rel="noopener noreferrer">
              <ButtonPremium className="sm:px-8">
                Veja os planos <ArrowRight className="ml-2 h-4 w-4 inline" />
              </ButtonPremium>
            </a>
            <a href="https://sistemgestor.appnfe.com/" target="_blank" rel="noopener noreferrer">
              <ButtonPremium variant="secondary">
                Certificado Digital
              </ButtonPremium>
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full animate-fade-in-slow">
            {[
              {
                icon: FileText,
                title: "Emissão Rápida",
                description: "Notas fiscais emitidas em segundos",
              },
              {
                icon: Cloud,
                title: "100% na Nuvem",
                description: "Acesse de qualquer lugar",
              },
              {
                icon: Smartphone,
                title: "Multiplataforma",
                description: "Use no celular ou computador",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-2xl bg-white shadow-lg hover:shadow-xl transition-shadow"
              >
                <feature.icon className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
