import ButtonPremium from "../ui/button-premium";
import { Check } from "lucide-react";

const PricingCard = ({ 
  plan, 
  price, 
  features, 
  highlight = false,
  description 
}: { 
  plan: string;
  price: string;
  features: string[];
  highlight?: boolean;
  description?: string;
}) => (
  <div className={`p-6 rounded-2xl ${highlight ? 'bg-primary shadow-xl scale-105' : 'bg-white shadow-lg'}`}>
    <div className="text-center">
      <h3 className={`text-xl font-bold mb-2 ${highlight ? 'text-white' : 'text-primary'}`}>{plan}</h3>
      <div className={`text-3xl font-bold mb-2 ${highlight ? 'text-white' : 'text-primary'}`}>
        R$ {price}
        <span className="text-sm font-normal">/mensal</span>
      </div>
      {description && (
        <p className={`text-sm mb-6 ${highlight ? 'text-white/80' : 'text-gray-600'}`}>
          {description}
        </p>
      )}
      <a href="https://sistemgestor.appnfe.com/" target="_blank" rel="noopener noreferrer" className="block w-full">
        <ButtonPremium 
          variant={highlight ? "primary" : "secondary"}
          className="w-full mb-6"
        >
          Começar Agora
        </ButtonPremium>
      </a>
    </div>
    <div className="space-y-4">
      {features.map((feature, index) => (
        <div key={index} className="flex items-center space-x-3">
          <Check className={`h-5 w-5 ${highlight ? 'text-white' : 'text-primary'}`} />
          <span className={highlight ? 'text-white' : 'text-gray-600'}>{feature}</span>
        </div>
      ))}
    </div>
  </div>
);

const Pricing = () => {
  const plans = [
    {
      plan: "Plano Micro",
      price: "44,90",
      description: "10 notas por mês",
      features: [
        "2 usuários",
        "Certificado digital",
        "Nota ficiais",
        "Suporte"
      ]
    },
    {
      plan: "Plano Start",
      price: "89,90",
      description: "100 notas por mês MELHOR CUSTO BENEFÍCIO PARA QUEM ESTA INICIANDO UM NEGOCIO",
      features: [
        "Tudo do plano Micro",
        "5 Usuários",
        "Notas Fiscais",
        "Certificado Digital"
      ],
      highlight: true
    },
    {
      plan: "Plano Turbo",
      price: "119,00",
      description: "MELHOR CUSTO BENEFÍCIO PARA QUEM EMITE MAIS DE 100 NFs OU NFC-e POR MÊS",
      features: [
        "Tudo do plano Start",
        "10 Usuários",
        "Nota Fiscais",
        "Certificado digital"
      ]
    },
    {
      plan: "Plano Master",
      price: "199,00",
      description: "Notas Ilimitadas",
      features: [
        "Tudo do plano Turbo",
        "15 Usuários",
        "Integrações e-commerce",
        "Finanças"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Escolha seu plano</h2>
          <p className="text-xl text-white/80">
            Temos o plano ideal para o seu negócio
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan, index) => (
            <PricingCard key={index} {...plan} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
